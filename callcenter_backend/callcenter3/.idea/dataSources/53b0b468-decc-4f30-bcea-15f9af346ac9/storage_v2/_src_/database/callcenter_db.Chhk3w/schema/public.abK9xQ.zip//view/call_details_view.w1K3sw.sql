create view call_details_view
            (call_id, call_time, call_date, call_duration, customer_id, customer_name, customer_surname, description,
             service_type, city, district, township, neighbourhood, operator_id)
as
SELECT oc.call_id,
       cr.call_time,
       cr.call_date,
       cr.call_duration,
       oc.customer_id,
       c.customer_name,
       c.customer_surname,
       c.customer_explanation          AS description,
       s.service_type,
       city.city_name                  AS city,
       district.district_name          AS district,
       dtt.district_township_town_name AS township,
       n.neighbourhood_name            AS neighbourhood,
       oc.operator_id
FROM operator_customer oc
         JOIN call_records cr ON oc.call_id = cr.call_id
         JOIN customer c ON oc.customer_id = c.customer_id
         LEFT JOIN service s ON c.service_id = s.service_id
         LEFT JOIN address a ON c.address_id = a.address_id
         LEFT JOIN neighbourhood n ON a.neighbourhood_id = n.neighbourhood_id
         LEFT JOIN district_township_town dtt ON n.district_township_town_id = dtt.district_township_town_id
         LEFT JOIN district ON dtt.district_id = district.district_id
         LEFT JOIN city ON district.city_id = city.city_id;

alter table call_details_view
    owner to postgres;

grant delete, insert, select, update on call_details_view to aysel;

